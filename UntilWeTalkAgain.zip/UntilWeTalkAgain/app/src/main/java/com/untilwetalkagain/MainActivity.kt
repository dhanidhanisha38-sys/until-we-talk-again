package com.untilwetalkagain

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.time.LocalDate
import java.time.YearMonth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(File(filesDir, "data.json"))
        setContent { App(store) }
    }
}

@Composable
fun App(store: Store) {
    MaterialTheme(colorScheme = palettes[store.theme].scheme) {
        var cal by remember { mutableStateOf(Cal.TALK) }
        var tab by remember { mutableIntStateOf(0) }
        var rangeMode by remember { mutableStateOf(false) }
        var rs by remember { mutableStateOf<LocalDate?>(null) }
        var re by remember { mutableStateOf<LocalDate?>(null) }
        Scaffold(bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Text("📅") }, label = { Text("Calendar") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Text("📊") }, label = { Text("Dashboard") })
            }
        }) { pad ->
            Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp)) {
                Text(stringResource(R.string.app_name), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    palettes.forEachIndexed { i, p ->
                        FilterChip(store.theme == i, { store.setTheme(i) }, { Text(p.name) })
                    }
                }
                TabRow(cal.ordinal) {
                    Cal.values().forEach { c -> Tab(cal == c, { cal = c }, text = { Text(c.title) }) }
                }
                Spacer(Modifier.height(8.dp))
                if (tab == 0) CalendarScreen(store, cal, rangeMode, { rangeMode = it; if (!it) { rs = null; re = null } }, rs, re) { a, b -> rs = a; re = b }
                else Dashboard(store, cal, rs, re)
            }
        }
    }
}

@Composable
fun CalendarScreen(
    store: Store, cal: Cal, rangeMode: Boolean, setRangeMode: (Boolean) -> Unit,
    rs: LocalDate?, re: LocalDate?, setRange: (LocalDate?, LocalDate?) -> Unit
) {
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var dayOpen by remember { mutableStateOf<LocalDate?>(null) }
    var rangeDialog by remember { mutableStateOf(false) }
    val entries = store.forCal(cal)
    val today = LocalDate.now()

    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        TextButton({ ym = ym.minusMonths(1) }) { Text("◀") }
        Text("${ym.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${ym.year}",
            Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        TextButton({ ym = ym.plusMonths(1) }) { Text("▶") }
    }
    Row(Modifier.fillMaxWidth()) {
        listOf("S", "M", "T", "W", "T", "F", "S").forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp) }
    }
    val offset = ym.atDay(1).dayOfWeek.value % 7
    val cells: List<LocalDate?> = List(offset) { null } + (1..ym.lengthOfMonth()).map { ym.atDay(it) }
    cells.chunked(7).forEach { week ->
        Row(Modifier.fillMaxWidth()) {
            (week + List(7 - week.size) { null }).forEach { d ->
                if (d == null) Spacer(Modifier.weight(1f)) else {
                    val inRange = rs != null && (re ?: rs).let { e2 -> !d.isBefore(minOf(rs, e2)) && !d.isAfter(maxOf(rs, e2)) }
                    val bg = if (inRange) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    Box(Modifier.weight(1f).aspectRatio(0.85f).padding(2.dp)
                        .background(bg, RoundedCornerShape(8.dp))
                        .clickable {
                            if (rangeMode) {
                                if (rs == null || re != null) setRange(d, null)
                                else { setRange(rs, d); rangeDialog = true }
                            } else dayOpen = d
                        }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.dayOfMonth.toString(), fontSize = 14.sp,
                                fontWeight = if (d == today) FontWeight.ExtraBold else FontWeight.Normal)
                            Text(entries[d]?.status?.symbol ?: " ", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        FilterChip(rangeMode, { setRangeMode(!rangeMode) }, { Text("Select range") })
        if (rangeMode) Text("  " + when {
            rs == null -> "Tap start date"
            re == null -> "Tap end date"
            else -> "$rs → $re"
        }, fontSize = 13.sp)
    }
    Spacer(Modifier.height(10.dp))
    MonthSummary(store, ym)

    dayOpen?.let { d -> DayDialog(store, cal, d) { dayOpen = null } }
    if (rangeDialog && rs != null && re != null) {
        AlertDialog(onDismissRequest = { rangeDialog = false },
            title = { Text("Mark range") },
            text = { Text("${minOf(rs, re)} → ${maxOf(rs, re)} on the ${cal.title} calendar") },
            confirmButton = {
                Row {
                    listOf(Status.NO, Status.YES).forEach { s ->
                        TextButton({
                            Logic.datesIn(rs, re).forEach { d -> store.put(cal, d, store.get(cal, d).copy(status = s)) }
                            rangeDialog = false
                        }) { Text(s.symbol, fontSize = 28.sp) }
                    }
                }
            },
            dismissButton = { TextButton({ rangeDialog = false }) { Text("Cancel") } })
    }
}

@Composable
fun DayDialog(store: Store, cal: Cal, d: LocalDate, onClose: () -> Unit) {
    val e = store.get(cal, d)
    fun num(s: String) = s.filter { it.isDigit() }.take(2).toIntOrNull() ?: 0
    AlertDialog(onDismissRequest = onClose,
        title = { Text(d.toString()) },
        confirmButton = { TextButton(onClose) { Text("Close") } },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Status.NO, Status.YES).forEach { s ->
                        val on = e.status == s
                        if (on) Button({ store.put(cal, d, e.copy(status = null)) }) { Text(s.symbol, fontSize = 26.sp) }
                        else OutlinedButton({ store.put(cal, d, e.copy(status = s)) }) { Text(s.symbol, fontSize = 26.sp) }
                    }
                }
                if (cal == Cal.TALK && e.status == Status.YES) {
                    Spacer(Modifier.height(8.dp))
                    Text("How long did you talk? (optional)", fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val kb = KeyboardOptions(keyboardType = KeyboardType.Number)
                        OutlinedTextField(if (e.h == 0) "" else e.h.toString(), { store.put(cal, d, e.copy(h = num(it))) }, Modifier.weight(1f), label = { Text("h") }, singleLine = true, keyboardOptions = kb)
                        OutlinedTextField(if (e.m == 0) "" else e.m.toString(), { store.put(cal, d, e.copy(m = num(it))) }, Modifier.weight(1f), label = { Text("m") }, singleLine = true, keyboardOptions = kb)
                        OutlinedTextField(if (e.s == 0) "" else e.s.toString(), { store.put(cal, d, e.copy(s = num(it))) }, Modifier.weight(1f), label = { Text("s") }, singleLine = true, keyboardOptions = kb)
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(e.note, { store.put(cal, d, e.copy(note = it.take(140))) },
                    Modifier.fillMaxWidth(), label = { Text("Note (optional)") }, maxLines = 3)
            }
        })
}

@Composable
fun StatCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)
        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(4.dp)); content()
    }
}

fun since(n: Long?) = when (n) { null -> "never marked"; 1L -> "1 day"; else -> "$n days" }

@Composable
fun MonthSummary(store: Store, ym: YearMonth) {
    StatCard("Month summary") {
        Cal.values().forEach { c ->
            val e = store.forCal(c)
            Text("${c.title}: ✅ ${Logic.countMonth(e, ym, Status.YES)}   ❌ ${Logic.countMonth(e, ym, Status.NO)}")
        }
    }
}

@Composable
fun Dashboard(store: Store, cal: Cal, rs: LocalDate?, re: LocalDate?) {
    val e = store.forCal(cal)
    val today = LocalDate.now()
    StatCard("${cal.title} — streaks") {
        Text("✅ ${cal.yes}: ${since(Logic.daysSince(e, Status.YES, today))} since last")
        Text("❌ ${cal.no}: ${since(Logic.daysSince(e, Status.NO, today))} since last")
    }
    StatCard("${cal.title} — totals") {
        Text("✅ ${cal.yes}: ${Logic.total(e, Status.YES)} days")
        Text("❌ ${cal.no}: ${Logic.total(e, Status.NO)} days")
    }
    StatCard("Range totals") {
        if (rs == null || re == null) Text("Pick a start and end date on the calendar (Select range).")
        else {
            Text("${minOf(rs, re)} → ${maxOf(rs, re)}")
            Cal.values().forEach { c ->
                val ce = store.forCal(c)
                Text("${c.title}: ✅ ${Logic.countInRange(ce, rs, re, Status.YES)}   ❌ ${Logic.countInRange(ce, rs, re, Status.NO)}")
            }
        }
    }
    MonthSummary(store, YearMonth.now())
}
