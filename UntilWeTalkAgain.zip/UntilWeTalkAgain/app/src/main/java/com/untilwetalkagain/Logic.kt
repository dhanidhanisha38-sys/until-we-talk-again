package com.untilwetalkagain

import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

enum class Cal(val title: String, val yes: String, val no: String) {
    TALK("Talking", "Talking", "Not talking"),
    MEET("Meeting", "Met", "Did not meet")
}

enum class Status(val symbol: String) { NO("❌"), YES("✅") }

data class Entry(val status: Status? = null, val note: String = "", val h: Int = 0, val m: Int = 0, val s: Int = 0) {
    fun isEmpty() = status == null && note.isEmpty() && h == 0 && m == 0 && s == 0
}

/** Pure calculation logic (unit-tested). */
object Logic {
    /** Days from the most recent day marked [s] (not after [today]) to [today]; null if never marked. */
    fun daysSince(e: Map<LocalDate, Entry>, s: Status, today: LocalDate): Long? =
        e.filter { it.value.status == s && !it.key.isAfter(today) }.keys.maxOrNull()
            ?.let { ChronoUnit.DAYS.between(it, today) }

    /** Inclusive count of days marked [s] between start and end (either order). */
    fun countInRange(e: Map<LocalDate, Entry>, start: LocalDate, end: LocalDate, s: Status): Int {
        val lo = minOf(start, end); val hi = maxOf(start, end)
        return e.count { it.value.status == s && !it.key.isBefore(lo) && !it.key.isAfter(hi) }
    }

    fun countMonth(e: Map<LocalDate, Entry>, ym: YearMonth, s: Status) =
        countInRange(e, ym.atDay(1), ym.atEndOfMonth(), s)

    fun total(e: Map<LocalDate, Entry>, s: Status) = e.count { it.value.status == s }

    fun datesIn(start: LocalDate, end: LocalDate): List<LocalDate> {
        val lo = minOf(start, end); val hi = maxOf(start, end)
        return generateSequence(lo) { it.plusDays(1) }.takeWhile { !it.isAfter(hi) }.toList()
    }
}
