package com.untilwetalkagain

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/*
 * THEME COLORS: edit the hex values below. Three themes: Ocean, Midnight, Rose.
 * primary = buttons/selection, container = range highlight & cards, background/surface = page.
 */
class Pal(val name: String, val scheme: ColorScheme)

val palettes = listOf(
    Pal("Ocean", lightColorScheme(
        primary = Color(0xFF1565C0), primaryContainer = Color(0xFFBBDEFB), onPrimaryContainer = Color(0xFF0D2B52),
        background = Color(0xFFF4F9FF), surface = Color(0xFFF4F9FF), surfaceVariant = Color(0xFFE3EEF9))),
    Pal("Midnight", darkColorScheme(
        primary = Color(0xFFB39DDB), primaryContainer = Color(0xFF3B2F5C), onPrimaryContainer = Color(0xFFEADCFF),
        background = Color(0xFF121218), surface = Color(0xFF121218), surfaceVariant = Color(0xFF24232E))),
    Pal("Rose", lightColorScheme(
        primary = Color(0xFFC2185B), primaryContainer = Color(0xFFF8BBD0), onPrimaryContainer = Color(0xFF4A0A25),
        background = Color(0xFFFFF5F8), surface = Color(0xFFFFF5F8), surfaceVariant = Color(0xFFFCE4EC)))
)
