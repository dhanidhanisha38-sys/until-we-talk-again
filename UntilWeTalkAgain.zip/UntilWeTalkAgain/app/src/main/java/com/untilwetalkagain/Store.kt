package com.untilwetalkagain

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

/** Local JSON file in app-private storage. Every change is written immediately. */
class Store(private val file: File) {
    private val map = mutableStateMapOf<String, Entry>()
    var theme by mutableStateOf(0)
        private set

    init { load() }

    private fun key(c: Cal, d: LocalDate) = "${c.name}|$d"
    fun get(c: Cal, d: LocalDate): Entry = map[key(c, d)] ?: Entry()

    fun put(c: Cal, d: LocalDate, e: Entry) {
        if (e.isEmpty()) map.remove(key(c, d)) else map[key(c, d)] = e
        save()
    }

    fun setTheme(i: Int) { theme = i; save() }

    fun forCal(c: Cal): Map<LocalDate, Entry> =
        map.filterKeys { it.startsWith(c.name + "|") }.mapKeys { LocalDate.parse(it.key.substringAfter('|')) }

    private fun save() {
        val root = JSONObject().put("theme", theme)
        val days = JSONObject()
        map.forEach { (k, e) ->
            days.put(k, JSONObject().put("s", e.status?.name ?: "").put("n", e.note)
                .put("h", e.h).put("m", e.m).put("x", e.s))
        }
        file.writeText(root.put("days", days).toString())
    }

    private fun load() {
        try {
            if (!file.exists()) return
            val root = JSONObject(file.readText())
            theme = root.optInt("theme", 0)
            val days = root.optJSONObject("days") ?: return
            days.keys().forEach { k ->
                val o = days.getJSONObject(k)
                map[k] = Entry(Status.values().firstOrNull { it.name == o.optString("s") },
                    o.optString("n"), o.optInt("h"), o.optInt("m"), o.optInt("x"))
            }
        } catch (_: Exception) { }
    }
}
