package com.untilwetalkagain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class LogicTest {
    private val d = { n: Int -> LocalDate.of(2026, 11, n) }
    private val data = mapOf(
        d(1) to Entry(Status.YES), d(2) to Entry(Status.NO), d(3) to Entry(Status.NO),
        d(5) to Entry(Status.YES), d(20) to Entry(Status.YES)
    )

    @Test fun streakCountsFromLastMark() {
        assertEquals(5L, Logic.daysSince(data, Status.YES, d(10)))
        assertEquals(7L, Logic.daysSince(data, Status.NO, d(10)))
    }
    @Test fun futureMarksIgnoredAndNeverIsNull() {
        assertNull(Logic.daysSince(emptyMap(), Status.YES, d(10)))
        assertEquals(5L, Logic.daysSince(data, Status.YES, d(10))) // d(20) is in the future
    }
    @Test fun rangeCountsAreInclusiveAndOrderIndependent() {
        assertEquals(2, Logic.countInRange(data, d(1), d(5), Status.YES))
        assertEquals(2, Logic.countInRange(data, d(5), d(1), Status.YES))
        assertEquals(2, Logic.countInRange(data, d(2), d(3), Status.NO))
        assertEquals(0, Logic.countInRange(data, d(6), d(19), Status.YES))
    }
    @Test fun meetingAndTalkingAreIndependentMaps() {
        val meet = mapOf(d(4) to Entry(Status.NO))
        assertEquals(1, Logic.countInRange(meet, d(1), d(30), Status.NO))
        assertEquals(0, Logic.countInRange(data, d(4), d(4), Status.NO))
    }
}
