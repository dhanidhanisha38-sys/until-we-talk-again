# Until We Talk Again — build & install (no Android Studio)

1. Make a free account at https://github.com and create a new repository (any name, Public or Private).
2. Upload this project's files to it (Add file > Upload files; easiest on a computer browser: drag the unzipped folder contents in).
   The hidden folder `.github/workflows/build.yml` must be included. If it didn't upload, use
   Add file > Create new file, name it `.github/workflows/build.yml`, and paste the file's text.
3. Open the repo's **Actions** tab. The "Build APK" run starts by itself (about 5 min). Wait for the green check.
4. Open the repo's **Releases** (right side of the main page), tap `app-debug.apk` to download it.
5. On your phone open the downloaded file. If asked, allow "Install unknown apps" for your browser/file manager, then Install.

Rename the app: `app/src/main/res/values/strings.xml` (`app_name`).
Theme colors: `app/src/main/java/com/untilwetalkagain/Theme.kt`.
Tests (streaks and range counts) run in the build: `app/src/test/.../LogicTest.kt`.
